<?php get_header(); ?>
 
 
  <section id="main">
 

  
<div id="areaerror">

<div id="error404" class="error404"></div>
<div id="error404msj" class="error404msj" align="center">Lo sentimos, la página que está buscando ya no existe</div>

</div>
 

  
 

  </section> <!-- Fin de main -->
 
    <?php //  get_sidebar();?>
 

<?php get_footer(); ?>