<footer>
<?php // bloginfo('name');  echo date('Y');?>
 
</footer>
 
</div> <!-- Fin de wrapper -->
 
<?php wp_footer(); ?>
</body>
</html>